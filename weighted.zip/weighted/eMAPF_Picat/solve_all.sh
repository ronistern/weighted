#!/bin/bash

for file in instances/*
do
	name=$(echo $file | cut -d/ -f2)
	echo solving $name

	timeout 1000 ./picat ms $file > tmp

	makespan=$(grep "makespan = " tmp | cut -d" " -f3)
	el_time=$(grep CPU tmp | cut -d" " -f3)

	echo $name';'$makespan';'$el_time >> results.txt
	rm -f tmp

	echo "done"
done